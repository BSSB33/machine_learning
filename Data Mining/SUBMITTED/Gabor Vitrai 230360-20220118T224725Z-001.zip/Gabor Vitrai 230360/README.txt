RUNNING SCRIP:
Download resoures, place them in the folder next to the script.
Run: py code.py


Dataset
Data Structure
The Structure of the set is built on 3 main classes: Condition, Therapy, Patient. To support the rest of the requirements with the dates and success rates, two additional classes were created. These are the Patient\_Condition and Patient\_Therapy. These are similar classes with the requested additional attributes, functioning as a sort of connector class / table. 

Data Generation
The generated dataset contains a 100 patients, 321 conditions and 22 therapies.
The number of available therapies were reduced to 22 so this way, the random therapy selection will result in some of the available therapies being actually useful for some of the conditions.
It was randomly determined how many conditions and trials a patient can have. (1-5 each)

To generate the dataset, first I downloaded and filtered the conditions, therapies, and patient names from the given resources [1]. To do so, I implemented some fairy simple scripts with a common baseline:

    import random library;
    open resource file;
    select X random names;
    capitalize names;
    sort names;
    export output;   
    exit;

I implemented helper functions to generate dates for the day of the diagnosis and ending of the therapy. Date generation pays attention to the beginning of the therapies so they start on the day as the condition was diagnosed. Therapy generation also influences the final outcome of the conditions. If a therapy was more then 75\% effective, it is considered successful. This case the condition is cured for the given patient. Otherwise the "cured" attribute remains "null".

Export / Import
To have the ability to sufficiently transfer the data into python dictionaries and JSON files, I implemented the needed import and export methods using the python JSON library. These methods can handle the embedded connections between patients and conditions/therapies with the connector classes involved.

Patient Observations Regarding Data Generation
In the example below, we can observe how Patient number 70 has 2 conditions. Condition number 229 was attempted to be cured 2x, the first therapy failed with a 15% success rate, while the second therapy (Th2) managed to cure the condition. Note that the first therapy was started when the condition was diagnosed, and the second therapy was started on the day when the first therapy was finished. (Possibly at a visit with the doctor). Condition 191 was attempted to cure 3 times, but all of them failed, so it remained uncured.

"id": 70,
"name": "Rizzuti",
"conditions": [
    {
        "id": "pc146",
        "diagnosed": "20161003",
        "cured": "20201104",
        "kind": "Cond229"
    },
    {
        "id": "pc147",
        "diagnosed": "20120413",
        "cured": null,
        "kind": "Cond191"
    }
],
"trials": [
    {
        "id": "tr180",
        "start": "20161003",
        "end": "20190709",
        "condition": "pc146",
        "therapy": "Th16",
        "successful": 15
    },
    {
        "id": "tr181",
        "start": "20190709",
        "end": "20201104",
        "condition": "pc146",
        "therapy": "Th2",
        "successful": 83
    },
    {
        "id": "tr182",
        "start": "20120413",
        "end": "20201030",
        "condition": "pc147",
        "therapy": "Th6",
        "successful": 63
    },
    {
        "id": "tr183",
        "start": "20201030",
        "end": "20210119",
        "condition": "pc147",
        "therapy": "Th15",
        "successful": 14
    },
    {
        "id": "tr184",
        "start": "20210119",
        "end": "20211003",
        "condition": "pc147",
        "therapy": "Th3",
        "successful": 7
    }
]